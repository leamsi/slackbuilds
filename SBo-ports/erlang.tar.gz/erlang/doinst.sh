chroot . ./usr/lib/erlang/Install -minimal usr/lib/erlang > /dev/null 2> /dev/null
